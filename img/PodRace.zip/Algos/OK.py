# -*- coding: utf-8 -*-
"""
Created on Sun Mar 18 13:17:42 2018

@author: FC
"""
import numpy as np

D=80
dt=1/20
nbb=2

def algo(pos,vit,direction,adv,vit_adv,porte,portes,debut=False):
    global D,dt,nbb
    if adv is None:
        adv=porte
    if debut:
        nbb=2
    dx,dy=porte[0]-pos[0],porte[1]-pos[1]
    vx,vy=vit
    dx,dy=dx-vx/2,dy-vy/2
    v=abs(vx+1j*vy)
    if vx!=0 or vy!=0:
        ux,uy=vx/v,vy/v
    else:
        ux,uy=0,0
    # Prochaines lignes à compléter
    # Calculer l'angle alpha entre l'horizontale et le vecteur OP
    # où O est votre position, P celle de la porte
    alpha=np.arctan2(dy,dx)
    # Calculer l'écart entre alpha et votre direction
    ecart=alpha- direction
    # Dans quel cas accélère-t-on ? Dans quel cas faut-il tourner ?
    if (abs(ecart)%(2*np.pi))<np.pi/10:
        return 0
    else:
        if (ecart%(2*np.pi))<np.pi:
            return 1
        else:
            return 2