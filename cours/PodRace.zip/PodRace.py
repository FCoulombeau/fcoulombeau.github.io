import res.game as game

definition=4


if 'PR' in globals():
    rep=input('Reinitialiser joueurs et circuit ? (0 pour non)')
    if rep!='0':
        rep=input('Circuit aléatoire, rectangulaire (0), triangulaire (1) ?')
        if rep=='0':
            PR=game.podrace(3,4,80,portes=[[100,100],[1500,800],[100,800],[1500,100]])
        elif rep=='1':
            PR=game.podrace(3,4,80,portes=[[100,100],[800,450],[1500,450],[100,800]])
        else:
            PR=game.podrace(3,4,80)
else:
    rep=input('Circuit aléatoire, rectangulaire (0), triangulaire (1) ?')
    if rep=='0':
        PR=game.podrace(3,4,80,portes=[[100,100],[1500,800],[100,800],[1500,100]])
    elif rep=='1':
        PR=game.podrace(3,4,80,portes=[[100,100],[800,450],[1500,450],[100,800]])
    else:
        PR=game.podrace(3,4,80)
rep=input('Course solo (1), duo (2) ou mêlée (0) ?')
if rep=='1' or rep=='2':
    PR.liste_joueurs()
    if rep=='1':
        rep=input('Quel joueur voulez vous faire jouer ? (donner son indice)')
        print('Circuit accompli en :',PR.partiesolo(PR.joueurs[int(rep)],enr=True,definition=definition))
        if game.video:
            print('La video de la course se trouve dans le dossier VideoCourse')
        else:
            print('Les images de la course se trouvent dans le dossier ImagesCourse')
    else:
        rep1=input('Premier joueur ? (donner son indice)')
        rep2=input('Deuxième joueur ? (donner son indice)')
        print(PR.partieduo(PR.joueurs[int(rep1)],PR.joueurs[int(rep2)],enr=True,definition=definition))
        if game.video:
            print('La video de la course se trouve dans le dossier VideoCourse')
        else:
            print('Les images de la course se trouvent dans le dossier ImagesCourse')
else:
    for i in range(len(PR.joueurs)):
        print(PR.joueurs[i].nom)
        print(format(PR.partiesolo(PR.joueurs[i]),'.2f'))
    PR.melee(enr=True,definition=definition)
