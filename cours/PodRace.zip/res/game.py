# -*- coding: utf-8 -*-
"""
Created on Fri Mar 23 17:18:02 2018

@author: FC
"""

import matplotlib.pyplot as plt
import numpy as np
try:
    import moviepy.editor as mpy
    video=True
except Exception:
    video=False
    print("Video désactivée tant que moviepy n'est pas installé.")
import random as r
import os
import sys as sys
import time as t


SpShs=[]
SpShB=[]
for i in range(20):
    SpSh=plt.imread('./res/SpSh-'+str(i)+'.jpg')
    SpShs.append(SpSh)
    SpSh=plt.imread('./res/SpShB-'+str(i)+'.jpg')
    SpShB.append(SpSh)

Gate=plt.imread('./res/Gate.jpg')
hh,ll=Gate.shape[:2]
    
terrain=plt.imread('./res/dune.jpg')
H,L=terrain.shape[:2]
h,l=SpShs[0].shape[:2]

A=400
alpha=1.
dt=1/20

D=(h//2+hh/2)*0.95

def prt(s):
    """ Writes and flushes without delay a text in the console """
    sys.stdout.write(s)
    sys.stdout.flush()

class joueur:
    def __init__(self,fic_algo):
        f=__import__('Algos.'+fic_algo,fromlist=['./Algos'])
#        print(fic_algo)
        self.algo=f.algo
        self.score=0
        self.nom=fic_algo
        self.res=[0,0,0]

class podrace:
    def __init__(self,nbtours,nbportes,tmax,portes=[]):
        self.fic_algos=[el[:-3] for el in os.listdir('./Algos') if el[-3:]=='.py']
        self.joueurs=[]
        for f in self.fic_algos:
            J=joueur(f)
            self.joueurs.append(J)
        self.imax=int(tmax*20)
        self.nbtours=nbtours
        if portes:
            self.nbportes=len(portes)
            self.portes=portes[:]
        else:
            self.nbportes=nbportes
            self.portes=[[r.randint(ll//2,L-ll//2),r.randint(hh//2,H-hh//2)] for k in range(nbportes)]
        
    def change_circuit(self,nbp):
        self.nbportes=nbp
        self.portes=[[r.randint(ll//2,L-ll//2),r.randint(hh//2,H-hh//2)] for k in range(nbp)]
        return r
    
    def partiesolo(self,joueur,enr=False,definition=4):
        nbb=2
        algo=joueur.algo
        To,Po=0,1
        score=[[To,Po]]
        P=self.portes[0][:]
        V=[0,0]
        angl=int(np.round(np.arctan2(self.portes[1][1]-P[1],self.portes[1][0]-P[0])/np.pi*10-5)%20)
        etat=1
        etats=[]
#        etats.append((etat,angl))        
        i=0
        while To<self.nbtours and i<self.imax:
            pe=algo(np.copy(P),np.copy(V),
                    np.pi/2+angl*np.pi/10,
                    None,None,
                    np.copy(self.portes[Po]),[np.copy(k).tolist() for k in self.portes],
                    debut=(i==0))
            if pe==3 and nbb>0:
                    nbb-=1
            if pe==3 and nbb==0:
                    pe=0
            etat=((pe==0)or(pe==3))*(pe+1)
            angl=(angl+1)%20 if pe==1 else (angl-pe//2)%20
            self.suivant(etat,angl,P,V)
            etats.append((etat,angl))
            if self.check(P,self.portes[Po]):
                Po=(Po+1)%self.nbportes
                if Po==1:
                    To+=1
            score.append([To,Po])
            i+=1
        P=self.portes[0][:]
        V=[0,0]
        angl=int(np.round(np.arctan2(self.portes[1][1]-P[1],self.portes[1][0]-P[0])/np.pi*10-5)%20)
        if enr:
            self.enregistrecourse(P,V,etats,score,self.portes,joueur.nom,definition=definition)
        return i*dt #, etats
    
    def partieduo(self,joueur1,joueur2,enr=False,definition=4):
        algo1,algo2=joueur1.algo,joueur2.algo
        nbb1=2
        nbb2=2
        ax,ay=self.portes[1][0]-self.portes[0][0],self.portes[1][1]-self.portes[0][1]
        n=abs(ax+1j*ay)
        ax,ay=-ay/n,ax/n
        To1,Po1=0,1
        score1=[[To1,Po1]]
        P1=[int(self.portes[0][0]+h/2*ax),int(self.portes[0][1]+h/2*ay)]
        V1=[0,0]
        To2,Po2=0,1
        score2=[[To2,Po2]]
        P2=[int(self.portes[0][0]-h/2*ax),int(self.portes[0][1]-h/2*ay)]
        V2=[0,0]
        angl1=int(np.round(np.arctan2(self.portes[1][1]-P1[1],self.portes[1][0]-P1[0])/np.pi*10-5)%20)
        etat1=1
        etats1=[]
#        etats1.append((etat1,angl1))  
        angl2=int(np.round(np.arctan2(self.portes[1][1]-P2[1],self.portes[1][0]-P2[0])/np.pi*10-5)%20)
        etat2=1
        etats2=[]
#        etats2.append((etat2,angl2))  
        i=0
        while To1<self.nbtours and To2<self.nbtours and i<self.imax:
            if etat1>-1:
                pe1=algo1(np.copy(P1),np.copy(V1),
                          np.pi/2+angl1*np.pi/10,
                          np.copy(P2),np.copy(V2),
                          np.copy(self.portes[Po1]),[np.copy(k).tolist() for k in self.portes],
                          debut=(i==0))
                if pe1==3 and nbb1>0:
                    nbb1-=1
                if pe1==3 and nbb1==0:
                    pe1=0
                etat1=((pe1==0)or(pe1==3))*(pe1+1)
                angl1=(angl1+1)%20 if pe1==1 else (angl1-pe1//2)%20
            else:
                etat1+=1
            if etat2>-1:
                pe2=algo2(np.copy(P2),np.copy(V2),
                          np.pi/2+angl2*np.pi/10,
                          np.copy(P1),np.copy(V1),
                          np.copy(self.portes[Po2]),[np.copy(k).tolist() for k in self.portes],
                          debut=(i==0))
                if pe2==3 and nbb2>0:
                    nbb2-=1
                if pe2==3 and nbb2==0:
                    pe2=0
                etat2=((pe2==0)or(pe2==3))*(pe2+1)
                angl2=(angl2+1)%20 if pe2==1 else (angl2-pe2//2)%20
            else:
                etat2+=1
            col=self.suivant2(etat1,angl1,P1,V1,etat2,angl2,P2,V2)
            etats1.append((etat1,angl1))
            etats2.append((etat2,angl2))
            if col:
                etat1=-3
                etat2=-3
            if self.check(P1,self.portes[Po1]):
                Po1=(Po1+1)%self.nbportes
                if Po1==1:
                    To1+=1
            if self.check(P2,self.portes[Po2]):
                Po2=(Po2+1)%self.nbportes
                if Po2==1:
                    To2+=1
            score1.append([To1,Po1])
            score2.append([To2,Po2])
            i+=1
        P1=[int(self.portes[0][0]+h/2*ax),int(self.portes[0][1]+h/2*ay)]
        V1=[0,0]
        P2=[int(self.portes[0][0]-h/2*ax),int(self.portes[0][1]-h/2*ay)]
        V2=[0,0]
        if enr:
            self.enregistrecourse2(P1,V1,etats1,score1,P2,V2,etats2,score2,self.portes,joueur1.nom+'-'+joueur2.nom,definition=definition)
        if To1==self.nbtours and To2!=self.nbtours:
            return 1 ,i*dt #, etats1, etats2
        if To2==self.nbtours:
            return 2 ,i*dt #, etats1, etats2
        return 0 ,i*dt #, etats1, etats2
                
    def bataille(self,J1,J2,verbose=True,wait=False):        
        b1=True
        b2=True
        r=self.partieduo(J1,J2)
        if r[0]==1:
            b1=True
            b2=False
        elif r[0]==2:
            b1=False
            b2=True
        else:
            b1=b2=False
        if wait:
            input("Appuyer sur Entrée")
        if b1:
            if verbose:
                print(J1.nom,'-',J2.nom,":",J1.nom,"gagne en",format(r[1],'.2f'))
            return 1,r[1]
        elif b2:
            if verbose:
                print(J1.nom,'-',J2.nom,":",J2.nom,"gagne en",format(r[1],'.2f'))
            return 2,r[1]
        else:
            if verbose:
                print(J1.nom,'-',J2.nom,":","Match nul !")
            return 0,r[1]
        
    def melee(self,verbose=True,bilan=None,enr=False,definition=4):
        def combat():
            m=-1
            for j1 in range(len(self.joueurs)):
                for j2 in range(len(self.joueurs)):
                    if j2==j1:
                        continue
                    J1=self.joueurs[j1]
                    J2=self.joueurs[j2]
                    r=self.bataille(J1,J2,verbose=verbose)
                    if m==-1:
                        m=r[1]
                        k1,k2=j1,j2
                    else:
                        if r[1]<=m and J1.nom!='naif' and J2.nom!='naif':
                            m=r[1]
                            k1,k2=j1,j2
                    if bilan:
                        if J1.nom in Js and r[0]!=1:
                            k=Js.index(J1.nom)
                            if r[0]==2:
                                bil[k].append("Perd contre "+J2.nom+"-aller. ")
                            else:
                                bil[k].append("Nul contre "+J2.nom+"-aller. ")
                        if J2.nom in Js and r[0]!=2:
                            k=Js.index(J2.nom)
                            if r[0]==1:
                                bil[k].append("Perd contre "+J1.nom+"-retour. ")
                            else:
                                bil[k].append("Nul contre "+J1.nom+"-retour. ")
                    if r[0]==1:
                        J1.score+=3
                        J1.res[0]+=1
                        J2.res[2]+=1
                    elif r[0]==2:
                        J2.score+=3
                        J2.res[0]+=1
                        J1.res[2]+=1
                    else:
                        J1.score+=1
                        J2.score+=1
                        J1.res[1]+=1
                        J2.res[1]+=1
            return k1,k2
        if bilan:
            Js=[self.joueurs[k].nom for k in bilan]
            print(Js)
            bil=[list() for k in bilan]
        a,b=combat()
        self.partieduo(self.joueurs[a],self.joueurs[b],enr=enr,definition=definition)
        save=True
        print('Score final ')
        self.joueurs.sort(key=lambda J:J.score)
        for J in self.joueurs:
            print(J.nom,J.score,'('+str(J.res[0])+';'+str(J.res[1])+';'+str(J.res[2])+')')
            J.score=0
            J.res=[0,0,0]
        if not save:
            self.partieduo(self.joueurs[-2],self.joueurs[-1],enr=enr,definition=definition)
        if bilan:
            print('Bilan')
            for n in range(len(bilan)):
                print(Js[n],':')
                for l in bil[n]:
                    print(l)
                n+=1

    def liste_joueurs(self):
        for j in range(len(self.joueurs)):
            print('Joueur n°',j,'- Nom :',self.joueurs[j].nom)

    def placevaisseau(self,pos,e,a,im,red=False,definition=2):
        x,y=pos
        if e==0:
            SpSh=SpShs[a][::definition,::definition,:3]
        else:
            SpSh=SpShB[a][::definition,::definition,:3]
        i=(H-y-h//2)//definition
        j=(x-l//2)//definition
        ml=max(0,-i)
        mc=max(0,-j)
        Ml=min(h//definition,H//definition-i)
        Mc=min(l//definition,L//definition-j)
        if ml<h//definition-1 and Ml>0 and mc<l//definition-1 and Mc>0:
            indices=(SpSh[ml:Ml,mc:Mc,0]<175)|(SpSh[ml:Ml,mc:Mc,1]<175)|(SpSh[ml:Ml,mc:Mc,2]<175)
            im[i+ml:i+Ml,j+mc:j+Mc][indices]=SpSh[ml:Ml,mc:Mc][indices]
            if red:
                im[i+ml:i+Ml,j+mc:j+Mc,0][indices]=255
            else:
                im[i+ml:i+Ml,j+mc:j+Mc,2][indices]=255
        
    def placeportes(self,pos,im,score1,score2=None,definition=2,red=False):
        Gat=Gate[::definition,::definition,:3]
        for k in range(len(pos)):
            x,y=pos[k]
            i=(H-y-hh//2)//definition
            j=(x-ll//2)//definition
            ml=max(0,-i)
            mc=max(0,-j)
            Mc=min(ll//definition,L//definition-j)
            Ml=min(hh//definition,H//definition-i)
            if ml<hh//definition and Ml>0 and mc<ll//definition and Mc>0:
                indices=(Gat[ml:Ml,mc:Mc,0]<250)&(Gat[ml:Ml,mc:Mc,1]<250)&(Gat[ml:Ml,mc:Mc,2]<250)
                im[i+ml:i+Ml,j+mc:j+Mc][indices]=Gat[ml:Ml,mc:Mc][indices]
                if k==score1[1]:
                    if red:
                        im[i+ml:i+Ml,j+mc:j+Mc,0][indices]=255
                    else:
                        im[i+ml:i+Ml,j+mc:j+Mc,2][indices]=255
                if score2:
                    if k==score2[1]:
                        im[i+ml:i+Ml,j+mc:j+Mc,0][indices]=255
            rond=np.array([[(i**2+j**2)<26 for j in range(-5,6)] for i in range(-5,6)])
            for i in range(score1[0]):
                if red:
                    im[420//definition+16*i:420//definition+11+16*i,-12:-23:-1][rond]=[255,128,128]
                else:
                    im[420//definition+16*i:420//definition+11+16*i,12:23][rond]=[128,128,255]
            if score2:
                for i in range(score2[0]):
                    im[420//definition+16*i:420//definition+11+16*i,-12:-23:-1][rond]=[255,128,128]
                    
    
    def check(self,pos,porte):
        return ((pos[0]-porte[0])**2+(pos[1]-porte[1])**2)<(D)**2
    
    def suivant(self,e,a,P,V):
        P[0]=int(P[0]+V[0]*dt+np.cos(np.pi/2+np.pi*a/10)*400*dt*(e==4))
        P[1]=int(P[1]+V[1]*dt+np.sin(np.pi/2+np.pi*a/10)*400*dt*(e==4))
        V[0]=V[0]+np.cos(np.pi/2+np.pi*a/10)*400*(e==4)+dt*(A*np.cos(np.pi/2+np.pi*a/10)*e-alpha*V[0])
        V[1]=V[1]+np.sin(np.pi/2+np.pi*a/10)*400*(e==4)+dt*(A*np.sin(np.pi/2+np.pi*a/10)*e-alpha*V[1])
    
    def suivant2(self,e1,a1,P1,V1,e2,a2,P2,V2):
        b=False
        nx1=int(P1[0]+V1[0]*dt+np.cos(np.pi/2+np.pi*a1/10)*400*dt*(e1==4))
        ny1=int(P1[1]+V1[1]*dt+np.sin(np.pi/2+np.pi*a1/10)*400*dt*(e1==4))
        nx2=int(P2[0]+V2[0]*dt+np.cos(np.pi/2+np.pi*a2/10)*400*dt*(e2==4))
        ny2=int(P2[1]+V2[1]*dt+np.sin(np.pi/2+np.pi*a2/10)*400*dt*(e2==4))
        d=abs(nx2-nx1+1j*(ny2-ny1))
        V1[0]=V1[0]+np.cos(np.pi/2+np.pi*a1/10)*400*(e1==4)+dt*(A*np.cos(np.pi/2+np.pi*a1/10)*e1-alpha*V1[0])
        V1[1]=V1[1]+np.sin(np.pi/2+np.pi*a1/10)*400*(e1==4)+dt*(A*np.sin(np.pi/2+np.pi*a1/10)*e1-alpha*V1[1])
        V2[0]=V2[0]+np.cos(np.pi/2+np.pi*a2/10)*400*(e2==4)+dt*(A*np.cos(np.pi/2+np.pi*a2/10)*e2-alpha*V2[0])
        V2[1]=V2[1]+np.sin(np.pi/2+np.pi*a2/10)*400*(e2==4)+dt*(A*np.sin(np.pi/2+np.pi*a2/10)*e2-alpha*V2[1])
        if d<h*0.8:
            b=True
            dvx,dvy=V2[0]-V1[0],V2[1]-V1[1]
            V1[:],V2[:]=V2[:],V1[:]
            V1[0]+=-dvy*0.1
            V1[1]+=dvx*0.1
            V2[0]-=-dvy*0.1
            V2[1]-=dvx*0.1
            mx=(nx1+nx2)/2
            my=(ny1+ny2)/2
            amx=(P1[0]+P2[0])/2
            amy=(P1[1]+P2[1])/2
            dx,dy=P1[0]-amx,P1[1]-amy
            d=abs(dx+1j*dy)
            dx,dy=dx/d,dy/d
            P1[0]=int(mx+h*0.4*dx)
            P1[1]=int(my+h*0.4*dy)
            P2[0]=int(mx-h*0.4*dx)
            P2[1]=int(my-h*0.4*dy)
        else:
            P1[0]=nx1
            P1[1]=ny1
            P2[0]=nx2
            P2[1]=ny2 
        return b
        
    def enregistrecourse(self,P0,V0,etats,score,portes,nom,definition=4):
        files=os.listdir('./ImagesCourse/')
        for f in files:
            os.remove('./ImagesCourse/'+f)
        P=P0[:]
        V=V0[:]
        n=len(etats)
        T=t.clock()
        for i in range(n):
            e,a=etats[i]
            self.suivant(e,a,P,V)
            image=np.copy(terrain[::definition,::definition,:3])
            self.placeportes(portes,image,score[i],definition=definition)
            self.placevaisseau([P[0],P[1]],e,a,image,definition=definition)
            plt.imsave('./ImagesCourse/'+nom+format(i,'04d')+'.jpg',image)
            if i%(n//100)==0 and i!=0:
                dT=t.clock()-T
                s="Création des images : "+str(i)+'/'+str(n+1)+'['+str(int(dT))+'\'+'+str(int(dT/i*(n-i)))+'\']  '
                prt('\r'+s)
        print()
        if video:
            vid=mpy.ImageSequenceClip('./ImagesCourse/',fps=20)
            vid.write_videofile('./VideoCourse/'+nom+'.webm',fps=20,codec='libvpx')
    
    def enregistrecourse2(self,P10,V10,etats1,score1,P20,V20,etats2,score2,portes,nom,definition=4):
        files=os.listdir('./ImagesCourse/')
        for f in files:
            os.remove('./ImagesCourse/'+f)
        P1=P10[:]
        V1=V10[:]
        P2=P20[:]
        V2=V20[:]
        n=min(len(etats1),len(etats2))
        T=t.clock()
        for i in range(n):
            self.suivant2(etats1[i][0],etats1[i][1],P1,V1,etats2[i][0],etats2[i][1],P2,V2)
    #        print(P1,P2)
            image=np.copy(terrain[::definition,::definition,:3])
            self.placeportes(portes,image,score1[i],score2[i],definition=definition)
            self.placevaisseau([P1[0],P1[1]],etats1[i][0],etats1[i][1],image,definition=definition)
            self.placevaisseau([P2[0],P2[1]],etats2[i][0],etats2[i][1],image,red=True,definition=definition)
            plt.imsave('./ImagesCourse/'+nom+format(i,'04d')+'.jpg',image)
            if i%(n//100)==0 and i!=0:
                dT=t.clock()-T
                s="Création des images : "+str(i)+'/'+str(n+1)+'['+str(int(dT))+'\'+'+str(int(dT/i*(n-i)))+'\']  '
                prt('\r'+s)
        print()
        if video:
            vid=mpy.ImageSequenceClip('./ImagesCourse/',fps=20)
            vid.write_videofile('./VideoCourse/'+nom+'.webm',fps=20,codec='libvpx')